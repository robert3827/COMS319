/**
 * Author: Robert Holeman
 * Net-id: holeman3
 * Date: 18 Sept 2023
 * Activity07 - Arrays
 */
console.log("---- I am in A R R A Y S ----")

// Q1 : Index of each color
let colors = ['red', 'blue', 'orange']
console.log(colors[0]);

// Q2 : Add a new element 'green'
colors[3] = 'green';
console.log(colors);
colors[4] = 'brown';

// Q3 : Length of the Array
console.log(colors.length);
